package com.fererlab;

public interface DataType {
}
