package com.fererlab;

public class DataTypeFirst implements DataType {
    @Key
    Integer a;
    Integer b;
    Double c;
    Long d;
    Boolean e;
    String f;
}
