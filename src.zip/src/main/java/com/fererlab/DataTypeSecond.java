package com.fererlab;

public class DataTypeSecond implements DataType {
    @Key
    Integer a;
    Double c;
    Boolean e;

}
