package com.fererlab;

public class PDataCenter implements DataType {
    @Key
    Integer index;
    Integer latencyToDataCenter;
}
